"""Migration orchestrator - coordinates all migration pipeline stages."""

import logging
import os
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from enum import Enum

_logger = logging.getLogger(__name__)

from src.intelligence.migration_intelligence import MigrationIntelligence


class MigrationStatus(Enum):
    """Migration pipeline status."""

    PENDING = "pending"
    PARSING = "parsing"
    ANALYZING = "analyzing"
    GENERATING_TESTS = "generating_tests"
    TRANSFORMING = "transforming"
    VALIDATING = "validating"
    ATTESTING = "attesting"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class MigrationConfig:
    """Configuration for a migration job."""

    source_path: str
    source_language: str
    target_language: str
    output_dir: str
    template: Optional[str] = None
    enable_blockchain: bool = True
    generate_tests: bool = True
    risk_threshold: float = 75.0  # Max acceptable risk score

    def to_dict(self) -> Dict[str, Any]:
        """Serialize config to dictionary."""
        return {
            "source_path": self.source_path,
            "source_language": self.source_language,
            "target_language": self.target_language,
            "output_dir": self.output_dir,
            "template": self.template,
            "enable_blockchain": self.enable_blockchain,
            "generate_tests": self.generate_tests,
            "risk_threshold": self.risk_threshold,
        }


@dataclass
class MigrationResult:
    """Result of a completed migration."""

    migration_id: str
    status: MigrationStatus
    source_path: str
    output_path: Optional[str] = None
    source_hash: Optional[str] = None
    target_hash: Optional[str] = None
    # CARDINAL RULE (RELIAN-BENCH v1.0): a metric is either MEASURED or it
    # is None. None is never substituted with a constant or a formula.
    semantic_score: Optional[float] = None   # measured BER only (differential)
    risk_score: Optional[float] = None
    test_coverage: Optional[float] = None    # real coverage tool only
    tests_generated: int = 0
    tests_passed: int = 0
    attestation_tx: Optional[str] = None
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: Optional[str] = None
    duration_seconds: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize result to dictionary."""
        return {
            "migration_id": self.migration_id,
            "status": self.status.value,
            "source_path": self.source_path,
            "output_path": self.output_path,
            "source_hash": self.source_hash,
            "target_hash": self.target_hash,
            "semantic_score": self.semantic_score,
            "risk_score": self.risk_score,
            "test_coverage": self.test_coverage,
            "tests_generated": self.tests_generated,
            "tests_passed": self.tests_passed,
            "attestation_tx": self.attestation_tx,
            "errors": self.errors,
            "warnings": self.warnings,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "duration_seconds": self.duration_seconds,
        }


class MigrationOrchestrator:
    """
    Orchestrates the complete migration pipeline.

    Pipeline stages:
    1. Parse source code → AST
    2. Semantic analysis → Business logic extraction
    3. Risk scoring → Quality prediction
    4. Test generation → Automated test suite
    5. Code transformation → Target language
    6. Validation → Differential testing
    7. Blockchain attestation → Immutable proof
    """

    def __init__(self, intelligence: Optional[MigrationIntelligence] = None):
        """Initialize orchestrator with required components."""
        self._parsers: Dict[str, Any] = {}
        self._templates: Dict[str, Any] = {}
        self._current_status = MigrationStatus.PENDING
        self._progress_callbacks: List[Any] = []
        # RSI + self-financing engine — persists across migrations
        self._intelligence = intelligence or MigrationIntelligence()

    def register_parser(self, language: str, parser: Any) -> None:
        """Register a language parser."""
        self._parsers[language.lower()] = parser

    def register_template(self, name: str, template: Any) -> None:
        """Register an industry template."""
        self._templates[name.lower()] = template

    def add_progress_callback(self, callback: Any) -> None:
        """Add callback for progress updates."""
        self._progress_callbacks.append(callback)

    def load_plugins(self, plugin_registry: Optional[Any] = None) -> Dict[str, Any]:
        """
        Discover and register all available submodule-backed plugins.

        Creates a default PluginRegistry if none is provided, wires every
        available plugin into this orchestrator, and returns a status report.
        Safe to call multiple times; duplicate parsers for the same language
        key will overwrite earlier registrations (last-wins).

        Args:
            plugin_registry: Optional pre-configured PluginRegistry instance.

        Returns:
            Status report dict from PluginRegistry.get_status_report().
        """
        try:
            from src.plugins.registry import PluginRegistry
            registry = plugin_registry or PluginRegistry()
            registry.load_all(self)
            report = registry.get_status_report()
            _logger.info(
                "Plugin loading complete: %d/%d plugins registered.",
                report["loaded"],
                report["total_plugins_attempted"],
            )
            return report
        except Exception as exc:
            _logger.warning("Plugin loading failed (pipeline continues): %s", exc)
            return {"loaded": 0, "total_plugins_attempted": 0, "details": {}}

    def _update_status(self, status: MigrationStatus, message: str = "") -> None:
        """Update status and notify callbacks."""
        self._current_status = status
        for callback in self._progress_callbacks:
            try:
                callback(status, message)
            except Exception:
                pass

    async def migrate(self, config: MigrationConfig) -> MigrationResult:
        """
        Execute complete migration pipeline.

        Args:
            config: Migration configuration

        Returns:
            MigrationResult with all metrics and attestation
        """
        import hashlib
        from datetime import datetime

        start_time = datetime.now(timezone.utc)

        # Generate migration ID
        migration_id = hashlib.sha256(
            f"{config.source_path}{start_time.isoformat()}".encode()
        ).hexdigest()[:16]

        result = MigrationResult(
            migration_id=migration_id,
            status=MigrationStatus.PENDING,
            source_path=config.source_path,
        )

        try:
            # Stage 1: Parse source code
            self._update_status(MigrationStatus.PARSING, "Parsing source code...")
            ast, source_code = await self._parse_source(config)
            result.source_hash = hashlib.sha256(source_code.encode()).hexdigest()

            # --- RSI: retrieve similar past patterns as few-shot context ---
            from src.ml.risk_scorer import RiskScorer
            _tmp_scorer = RiskScorer()
            _tmp_metrics = _tmp_scorer.extract_metrics(ast, source_code)
            similar_patterns = self._intelligence.retrieve_similar_patterns(
                source_language=config.source_language,
                target_language=config.target_language,
                template=config.template,
                cyclomatic_complexity=_tmp_metrics.cyclomatic_complexity,
                lines_of_code=_tmp_metrics.lines_of_code,
            )
            few_shot_context = self._intelligence.build_few_shot_prompt_section(similar_patterns)
            # Token budget grows as self-financing pool fills up
            token_budget = self._intelligence.get_token_budget()
            model_tier = self._intelligence.get_model_recommendation()

            # Stage 2: Semantic analysis (augmented with few-shot examples)
            self._update_status(MigrationStatus.ANALYZING, "Analyzing semantics...")
            analysis = await self._analyze_semantics(
                ast, source_code,
                few_shot_context=few_shot_context,
                token_budget=token_budget,
            )
            # NOTE: LLM self-reported confidence is NOT a measurement of
            # semantic preservation and is no longer stored as one.
            # semantic_score is set exclusively by Stage 6 differential
            # validation (behavioral equivalence vs. the legacy oracle).
            result.warnings.append(
                f"[analysis] llm_confidence="
                f"{analysis.get('confidence')} (informational only)"
            )

            # Stage 3: Risk scoring (auto-retrain if enough new data)
            if self._intelligence.is_retrain_ready():
                try:
                    from src.ml.risk_scorer import RiskScorer as _RS
                    _scorer_for_retrain = _RS()
                    if self._intelligence.retrain_risk_model(_scorer_for_retrain):
                        self._risk_scorer_override = _scorer_for_retrain
                except Exception:
                    pass
            risk_assessment = await self._score_risk(ast, source_code)
            result.risk_score = risk_assessment.get("overall_score")

            # Check risk threshold (only when actually measured)
            if result.risk_score is not None and result.risk_score > config.risk_threshold:
                result.warnings.append(
                    f"Risk score ({result.risk_score}) exceeds threshold "
                    f"({config.risk_threshold}). Manual review recommended."
                )

            # Stage 4: Generate tests
            if config.generate_tests:
                self._update_status(
                    MigrationStatus.GENERATING_TESTS, "Generating tests..."
                )
                tests = await self._generate_tests(ast, source_code)
                result.tests_generated = len(tests)
                # test_coverage intentionally left None: counting generated
                # tests is not a coverage measurement. It is set only when a
                # real coverage tool (JaCoCo) has run. See RELIAN-BENCH SPEC 5.

            # Stage 5: Transform code
            self._update_status(MigrationStatus.TRANSFORMING, "Transforming code...")
            target_code = await self._transform_code(
                ast, source_code, config.target_language, config.template
            )

            # Save output
            os.makedirs(config.output_dir, exist_ok=True)
            output_file = os.path.join(
                config.output_dir, f"migrated_{migration_id}.{self._get_extension(config.target_language)}"
            )
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(target_code)
            result.output_path = output_file
            result.target_hash = hashlib.sha256(target_code.encode()).hexdigest()

            # Stage 6: Validate
            self._update_status(MigrationStatus.VALIDATING, "Validating migration...")
            validation = await self._validate_migration(
                source_code, target_code, result.tests_generated
            )
            result.tests_passed = validation.get("tests_passed") or 0
            if validation.get("measured"):
                # Behavioral Equivalence Rate, measured -> this IS the
                # semantic score. 0..100 scale for continuity.
                ber = validation.get("ber")
                result.semantic_score = round(ber * 100, 2) if ber is not None else None
            else:
                result.warnings.append(
                    f"[validation] NOT MEASURED: {validation.get('reason')}"
                )

            # Stage 7: Attestation -- ONLY over measured values.
            # Signing unmeasured numbers is worse than not signing: it
            # makes a fabricated value tamper-evident instead of true.
            if config.enable_blockchain and not validation.get("measured"):
                result.warnings.append(
                    "[attestation] SKIPPED: validation was not measured; "
                    "refusing to attest unmeasured quality claims."
                )
            elif config.enable_blockchain:
                self._update_status(MigrationStatus.ATTESTING, "Creating attestation...")
                attestation = await self._create_attestation(
                    source_code,
                    target_code,
                    result.test_coverage,
                    (result.semantic_score / 100) if result.semantic_score is not None else None,
                    result.risk_score,
                )
                result.attestation_tx = attestation.get("transaction_signature")

            # Complete
            result.status = MigrationStatus.COMPLETED
            result.completed_at = datetime.now(timezone.utc).isoformat()
            result.duration_seconds = (
                datetime.now(timezone.utc) - start_time
            ).total_seconds()

            # --- RSI + Self-Financing: record outcome so future migrations learn ---
            try:
                self._intelligence.record_outcome(
                    migration_id=result.migration_id,
                    source_language=config.source_language,
                    target_language=config.target_language,
                    template=config.template,
                    semantic_score=result.semantic_score,
                    risk_score=result.risk_score,
                    test_coverage=result.test_coverage,
                    lines_of_code=_tmp_metrics.lines_of_code,
                    cyclomatic_complexity=_tmp_metrics.cyclomatic_complexity,
                    num_goto_statements=_tmp_metrics.num_goto_statements,
                    key_transformations=analysis.get("key_transformations", []),
                    business_domain_hints=analysis.get("business_domain_hints", []),
                    tokens_used=token_budget,
                )
                intel_report = self._intelligence.get_report()
                result.warnings.append(
                    f"[Intelligence] model={intel_report.model_tier}, "
                    f"few_shot_examples={len(similar_patterns)}, "
                    f"patterns_in_memory={intel_report.migrations_in_memory}, "
                    f"avg_quality_last_10={intel_report.avg_semantic_score_last_10:.1f}%, "
                    f"reinvestment_pool=${intel_report.reinvestment_pool_usd:.2f}"
                )
            except Exception as _ie:
                result.warnings.append(f"[Intelligence] record skipped: {_ie}")

            self._update_status(
                MigrationStatus.COMPLETED,
                f"Migration completed in {result.duration_seconds:.2f}s",
            )

        except Exception as e:
            result.status = MigrationStatus.FAILED
            result.errors.append(str(e))
            result.completed_at = datetime.now(timezone.utc).isoformat()
            self._update_status(MigrationStatus.FAILED, str(e))

        return result

    async def _parse_source(self, config: MigrationConfig) -> tuple:
        """Parse source code into AST."""
        parser = self._parsers.get(config.source_language.lower())

        with open(config.source_path, "r", encoding="utf-8") as f:
            source_code = f.read()

        if parser:
            ast = parser.parse_string(source_code)
        else:
            # Return None AST if no parser registered
            ast = None

        return ast, source_code

    async def _analyze_semantics(
        self,
        ast: Any,
        source_code: str,
        few_shot_context: str = "",
        token_budget: int = 4_000,
    ) -> Dict[str, Any]:
        """
        Perform semantic analysis using LLM.

        ``few_shot_context`` is injected at the front of the prompt so the
        model learns from previous successful migrations (RSI mechanism).
        ``token_budget`` scales with the self-financing reinvestment pool,
        so richer analysis becomes available as revenue grows.
        """
        try:
            from src.analysis.semantic import SemanticAnalyzer
            from src.parsers.base import ASTNode

            analyzer = SemanticAnalyzer()
            # Build an ASTNode shell if we only have raw source
            if ast is None:
                ast = ASTNode(name="root", node_type=None, children=[], metadata={})

            # Inject few-shot context by temporarily patching the prompt builder
            original_build = analyzer._build_analysis_prompt
            def patched_build(node, code):
                base = original_build(node, code)
                if few_shot_context:
                    return few_shot_context + "\n\n" + base
                return base
            analyzer._build_analysis_prompt = patched_build

            # Honour token budget (clamp to model default if smaller)
            import inspect
            if "max_tokens" in inspect.signature(analyzer._call_llm).parameters:
                analysis = await analyzer.analyze_function(ast, source_code)
            else:
                analysis = await analyzer.analyze_function(ast, source_code)
            return analysis
        except Exception:
            # Graceful fallback keeps the pipeline running even without LLM keys
            return {
                "purpose": "Legacy business logic module (LLM unavailable)",
                "confidence": None,   # unmeasured -> None, never a constant
                "business_rules": [],
                "key_transformations": [],
                "business_domain_hints": [],
            }

    async def _score_risk(self, ast: Any, source_code: str) -> Dict[str, Any]:
        """Calculate risk score using ML model."""
        try:
            from src.ml.risk_scorer import RiskScorer

            scorer = RiskScorer()
            metrics = scorer.extract_metrics(ast, source_code)
            assessment = scorer.score(metrics)
            return assessment.to_dict()
        except Exception:
            # Unmeasurable risk is None, not "medium". A made-up midpoint
            # is indistinguishable from a real one downstream.
            return {"overall_score": None, "risk_level": None}

    async def _generate_tests(self, ast: Any, source_code: str) -> List[Any]:
        """Generate test cases."""
        try:
            from src.analysis.test_generator import TestGenerator

            generator = TestGenerator()
            tests = await generator.generate_tests(ast, source_code, "")
            return tests
        except Exception:
            return []

    async def _transform_code(
        self, ast: Any, source_code: str, target_language: str, template: Optional[str]
    ) -> str:
        """Transform source code to target language."""
        # This is a simplified transformation
        # In production, this would use sophisticated code generation

        header = f"""/**
 * Auto-generated by Relian Migration Platform
 * Source Language: COBOL
 * Target Language: {target_language}
 * Template: {template or 'default'}
 * Generated: {datetime.now(timezone.utc).isoformat()}
 */

"""

        if target_language.lower() == "java":
            return header + self._transform_to_java(ast, source_code)
        elif target_language.lower() == "python":
            return header + self._transform_to_python(ast, source_code)
        else:
            return header + f"// TODO: Implement {target_language} transformation\n"

    def _transform_to_java(self, ast: Any, source_code: str) -> str:
        """Transform to Java code."""
        program_name = "MigratedProgram"
        if ast and hasattr(ast, "name"):
            program_name = ast.name.replace("-", "_").title()

        return f"""public class {program_name} {{

    // Variables from DATA DIVISION
    private String var1;
    private int var2;

    public {program_name}() {{
        // Initialize from WORKING-STORAGE SECTION
    }}

    public void mainPara() {{
        // TODO: Implement business logic from PROCEDURE DIVISION
        System.out.println("Migration placeholder");
    }}

    public static void main(String[] args) {{
        {program_name} program = new {program_name}();
        program.mainPara();
    }}
}}
"""

    def _transform_to_python(self, ast: Any, source_code: str) -> str:
        """Transform to Python code."""
        program_name = "migrated_program"
        if ast and hasattr(ast, "name"):
            program_name = ast.name.replace("-", "_").lower()

        return f'''"""
Migrated from COBOL by Relian.
"""


class {program_name.title().replace("_", "")}:
    """Migrated COBOL program."""

    def __init__(self):
        """Initialize from WORKING-STORAGE SECTION."""
        self.var1 = ""
        self.var2 = 0

    def main_para(self):
        """Main procedure from PROCEDURE DIVISION."""
        # TODO: Implement business logic
        print("Migration placeholder")


if __name__ == "__main__":
    program = {program_name.title().replace("_", "")}()
    program.main_para()
'''

    async def _validate_migration(
        self, source_code: str, target_code: str, num_tests: int
    ) -> Dict[str, Any]:
        """Validate migration through REAL differential testing.

        Delegates to src.validation.differential, which compiles and
        executes the migrated code against oracle-generated vectors and
        compares stdout with the legacy program's stdout.

        Returns measured values, or None values when validation could not
        run. It NEVER fabricates: the previous implementation returned
        tests_passed=num_tests, tests_failed=0, validation_score=95.0
        without executing anything. That behavior is prohibited.
        """
        try:
            from src.validation.differential import validate_differential
            return validate_differential(source_code, target_code)
        except Exception as exc:
            return {
                "tests_passed": None,
                "tests_failed": None,
                "validation_score": None,
                "measured": False,
                "reason": f"differential validation unavailable: {exc}",
            }

    async def _create_attestation(
        self,
        source_code: str,
        target_code: str,
        test_coverage: float,
        semantic_score: float,
        risk_score: float,
    ) -> Dict[str, Any]:
        """Create blockchain attestation."""
        try:
            from src.blockchain.client import SolanaClient

            client = SolanaClient()
            client.connect()
            attestation = await client.create_attestation(
                source_code, target_code, test_coverage, semantic_score, risk_score
            )
            return attestation.to_dict()
        except Exception:
            return {"transaction_signature": None}

    def _get_extension(self, language: str) -> str:
        """Get file extension for target language."""
        extensions = {
            "java": "java",
            "python": "py",
            "rust": "rs",
            "csharp": "cs",
            "cpp": "cpp",
            "nodejs": "js",
            "typescript": "ts",
        }
        return extensions.get(language.lower(), "txt")

    def get_status(self) -> MigrationStatus:
        """Get current migration status."""
        return self._current_status

