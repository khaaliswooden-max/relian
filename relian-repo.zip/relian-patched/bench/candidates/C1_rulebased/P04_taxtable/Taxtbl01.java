
import java.math.BigDecimal;
import java.math.RoundingMode;

final class R {
    static BigDecimal st(BigDecimal v, int scale, boolean rounded) {
        return v.setScale(scale, rounded ? RoundingMode.HALF_UP : RoundingMode.DOWN);
    }
    static String numval(String s) { s = s.trim(); return s.isEmpty() ? "0" : s; }
    static boolean eq(String a, String b) {
        return rtrim(a).equals(rtrim(b));
    }
    static String rtrim(String s) { int e = s.length(); while (e>0 && s.charAt(e-1)==' ') e--; return s.substring(0,e); }
    static int ix(BigDecimal v) { return v.intValue(); }
    static int ix(int v) { return v; }
    /* unedited numeric DISPLAY: zero-padded to declared digits */
    static String dnum(BigDecimal v, int intd, int dec) {
        BigDecimal x = v.setScale(dec, RoundingMode.DOWN);
        String s = x.abs().toPlainString();
        String ip = dec > 0 ? s.substring(0, s.indexOf('.')) : s;
        while (ip.length() < intd) ip = "0" + ip;
        String r = dec > 0 ? ip + s.substring(s.indexOf('.')) : ip;
        return (v.signum() < 0 ? "-" : "") + r;
    }
    /* edited picture then TRIM: plain decimal at edit scale */
    static String dedit(BigDecimal v, int dec) {
        return v.setScale(dec, RoundingMode.DOWN).toPlainString();
    }
    static String alpha(String s, int len) {
        return s.length() > len ? s.substring(0, len) : s;
    }
}

public class Taxtbl01 {
  public static void main(String[] args) {
    java.util.Scanner _sc = new java.util.Scanner(System.in);
    String WS_RAW = "";
    String WS_F1 = "";
    String WS_F2 = "";
    BigDecimal WS_INC = BigDecimal.ZERO;
    String WS_ST = "";
    BigDecimal[] BR_CEIL = new BigDecimal[5];
    java.util.Arrays.fill(BR_CEIL, BigDecimal.ZERO);
    BigDecimal[] BR_RATE = new BigDecimal[5];
    java.util.Arrays.fill(BR_RATE, BigDecimal.ZERO);
    BigDecimal[] BR_BASE = new BigDecimal[5];
    java.util.Arrays.fill(BR_BASE, BigDecimal.ZERO);
    BigDecimal WS_TAX = BigDecimal.ZERO;
    BigDecimal WS_IDX = BigDecimal.ZERO;
    BigDecimal WS_PREV = BigDecimal.ZERO;
    BigDecimal WS_MULT = BigDecimal.ZERO;
    String WS_O_TAX = "";
    String WS_O_MARG = "";
    int BI = 1;
    WS_RAW = _sc.hasNextLine() ? _sc.nextLine() : "";
    String[] _p = WS_RAW.split(",", -1);
    WS_F1 = _p.length > 0 ? _p[0] : "";
    WS_F2 = _p.length > 1 ? _p[1] : "";
    WS_INC = R.st(new BigDecimal(R.numval(WS_F1)), 2, false);
    WS_ST = R.alpha(WS_F2.trim(), 1);
    if (R.eq(WS_ST, "M")) {
      WS_MULT = R.st(new BigDecimal("2.00"), 2, false);
    } else {
      WS_MULT = R.st(new BigDecimal("1.00"), 2, false);
    }
    BR_CEIL[R.ix(new BigDecimal("1"))-1] = R.st(new BigDecimal("11600.00").multiply(WS_MULT), 2, false);
    BR_RATE[R.ix(new BigDecimal("1"))-1] = R.st(new BigDecimal("0.1000"), 4, false);
    BR_BASE[R.ix(new BigDecimal("1"))-1] = R.st(new BigDecimal("0.00"), 2, false);
    BR_CEIL[R.ix(new BigDecimal("2"))-1] = R.st(new BigDecimal("47150.00").multiply(WS_MULT), 2, false);
    BR_RATE[R.ix(new BigDecimal("2"))-1] = R.st(new BigDecimal("0.1200"), 4, false);
    BR_BASE[R.ix(new BigDecimal("2"))-1] = R.st(new BigDecimal("1160.00").multiply(WS_MULT), 2, false);
    BR_CEIL[R.ix(new BigDecimal("3"))-1] = R.st(new BigDecimal("100525.00").multiply(WS_MULT), 2, false);
    BR_RATE[R.ix(new BigDecimal("3"))-1] = R.st(new BigDecimal("0.2200"), 4, false);
    BR_BASE[R.ix(new BigDecimal("3"))-1] = R.st(new BigDecimal("5426.00").multiply(WS_MULT), 2, false);
    BR_CEIL[R.ix(new BigDecimal("4"))-1] = R.st(new BigDecimal("191950.00").multiply(WS_MULT), 2, false);
    BR_RATE[R.ix(new BigDecimal("4"))-1] = R.st(new BigDecimal("0.2400"), 4, false);
    BR_BASE[R.ix(new BigDecimal("4"))-1] = R.st(new BigDecimal("17168.50").multiply(WS_MULT), 2, false);
    BR_CEIL[R.ix(new BigDecimal("5"))-1] = R.st(new BigDecimal("999999999.00"), 2, false);
    BR_RATE[R.ix(new BigDecimal("5"))-1] = R.st(new BigDecimal("0.3200"), 4, false);
    BR_BASE[R.ix(new BigDecimal("5"))-1] = R.st(new BigDecimal("39110.50").multiply(WS_MULT), 2, false);
    BI = 1;
    boolean _found = false;
    for (; BI <= 5; BI++) {
      if ((WS_INC).compareTo(BR_CEIL[R.ix(BI)-1]) <= 0) {
        WS_IDX = R.st(new BigDecimal(BI), 0, false);
        _found = true; break;
      }
    }
    if (!_found) {
      WS_IDX = R.st(new BigDecimal("5"), 0, false);
    }
    if ((WS_IDX).compareTo(new BigDecimal("1")) == 0) {
      WS_PREV = R.st(BigDecimal.ZERO, 2, false);
    } else {
      WS_PREV = R.st(BR_CEIL[R.ix(WS_IDX.subtract(new BigDecimal("1")))-1], 2, false);
    }
    WS_TAX = R.st(BR_BASE[R.ix(WS_IDX)-1].add(WS_INC.subtract(WS_PREV).multiply(BR_RATE[R.ix(WS_IDX)-1])), 2, true);
    WS_O_TAX = R.dedit(WS_TAX, 2);
    WS_O_MARG = R.dedit(BR_RATE[R.ix(WS_IDX)-1], 4);
    System.out.println("TAX=" + WS_O_TAX.trim() + " BRACKET=" + R.dnum(WS_IDX, 1, 0) + " MARGINAL=" + WS_O_MARG.trim());
    return;
  }
}
