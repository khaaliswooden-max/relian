
import java.math.BigDecimal;
import java.math.RoundingMode;

final class R {
    static BigDecimal st(BigDecimal v, int scale, boolean rounded) {
        return v.setScale(scale, rounded ? RoundingMode.HALF_UP : RoundingMode.DOWN);
    }
    static String numval(String s) { s = s.trim(); return s.isEmpty() ? "0" : s; }
    static boolean eq(String a, String b) {
        return rtrim(a).equals(rtrim(b));
    }
    static String rtrim(String s) { int e = s.length(); while (e>0 && s.charAt(e-1)==' ') e--; return s.substring(0,e); }
    static int ix(BigDecimal v) { return v.intValue(); }
    static int ix(int v) { return v; }
    /* unedited numeric DISPLAY: zero-padded to declared digits */
    static String dnum(BigDecimal v, int intd, int dec) {
        BigDecimal x = v.setScale(dec, RoundingMode.DOWN);
        String s = x.abs().toPlainString();
        String ip = dec > 0 ? s.substring(0, s.indexOf('.')) : s;
        while (ip.length() < intd) ip = "0" + ip;
        String r = dec > 0 ? ip + s.substring(s.indexOf('.')) : ip;
        return (v.signum() < 0 ? "-" : "") + r;
    }
    /* edited picture then TRIM: plain decimal at edit scale */
    static String dedit(BigDecimal v, int dec) {
        return v.setScale(dec, RoundingMode.DOWN).toPlainString();
    }
    static String alpha(String s, int len) {
        return s.length() > len ? s.substring(0, len) : s;
    }
}

public class Validat01 {
  public static void main(String[] args) {
    java.util.Scanner _sc = new java.util.Scanner(System.in);
    String WS_RAW = "";
    String WS_F1 = "";
    String WS_F2 = "";
    String WS_F3 = "";
    String WS_ACCT = "";
    BigDecimal WS_AMT = BigDecimal.ZERO;
    String WS_STATE = "";
    BigDecimal WS_RC = BigDecimal.ZERO;
    String WS_MSG = "";
    BigDecimal WS_DIGITS = BigDecimal.ZERO;
    BigDecimal WS_LEN = BigDecimal.ZERO;
    int BI = 1;
    WS_RAW = _sc.hasNextLine() ? _sc.nextLine() : "";
    String[] _p = WS_RAW.split(",", -1);
    WS_F1 = _p.length > 0 ? _p[0] : "";
    WS_F2 = _p.length > 1 ? _p[1] : "";
    WS_F3 = _p.length > 2 ? _p[2] : "";
    WS_ACCT = R.alpha(WS_F1.trim(), 20);
    WS_AMT = R.st(new BigDecimal(R.numval(WS_F2)), 2, false);
    WS_STATE = R.alpha(WS_F3.trim(), 2);
    WS_DIGITS = R.st(BigDecimal.ZERO, 0, false);
    { int _c = 0; for (char _ch : WS_ACCT.toCharArray()) if ("0123456789".indexOf(_ch) >= 0) _c++; WS_DIGITS = new BigDecimal(_c); }
    WS_LEN = R.st(new BigDecimal(WS_ACCT.trim().length()), 0, false);
    WS_RC = R.st(new BigDecimal("0"), 0, false);
    WS_MSG = R.alpha("OK", 24);
    if ((WS_LEN).compareTo(new BigDecimal("8")) != 0) {
      WS_RC = R.st(new BigDecimal("101"), 0, false);
      WS_MSG = R.alpha("BAD ACCT LENGTH", 24);
    } else if ((WS_DIGITS).compareTo(new BigDecimal("8")) != 0) {
      WS_RC = R.st(new BigDecimal("102"), 0, false);
      WS_MSG = R.alpha("ACCT NOT NUMERIC", 24);
    } else if ((WS_AMT).compareTo(new BigDecimal("0")) == 0) {
      WS_RC = R.st(new BigDecimal("201"), 0, false);
      WS_MSG = R.alpha("ZERO AMOUNT", 24);
    } else if ((WS_AMT).compareTo(new BigDecimal("0")) < 0) {
      WS_RC = R.st(new BigDecimal("202"), 0, false);
      WS_MSG = R.alpha("NEGATIVE AMOUNT", 24);
    } else if ((WS_AMT).compareTo(new BigDecimal("10000.00")) > 0) {
      WS_RC = R.st(new BigDecimal("203"), 0, false);
      WS_MSG = R.alpha("EXCEEDS LIMIT", 24);
    } else if (R.eq(WS_STATE, "  ")) {
      WS_RC = R.st(new BigDecimal("301"), 0, false);
      WS_MSG = R.alpha("MISSING STATE", 24);
    }
    System.out.println("RC=" + R.dnum(WS_RC, 3, 0) + " MSG=" + WS_MSG.trim());
    return;
  }
}
