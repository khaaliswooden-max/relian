
import java.math.BigDecimal;
import java.math.RoundingMode;

final class R {
    static BigDecimal st(BigDecimal v, int scale, boolean rounded) {
        return v.setScale(scale, rounded ? RoundingMode.HALF_UP : RoundingMode.DOWN);
    }
    static String numval(String s) { s = s.trim(); return s.isEmpty() ? "0" : s; }
    static boolean eq(String a, String b) {
        return rtrim(a).equals(rtrim(b));
    }
    static String rtrim(String s) { int e = s.length(); while (e>0 && s.charAt(e-1)==' ') e--; return s.substring(0,e); }
    static int ix(BigDecimal v) { return v.intValue(); }
    static int ix(int v) { return v; }
    /* unedited numeric DISPLAY: zero-padded to declared digits */
    static String dnum(BigDecimal v, int intd, int dec) {
        BigDecimal x = v.setScale(dec, RoundingMode.DOWN);
        String s = x.abs().toPlainString();
        String ip = dec > 0 ? s.substring(0, s.indexOf('.')) : s;
        while (ip.length() < intd) ip = "0" + ip;
        String r = dec > 0 ? ip + s.substring(s.indexOf('.')) : ip;
        return (v.signum() < 0 ? "-" : "") + r;
    }
    /* edited picture then TRIM: plain decimal at edit scale */
    static String dedit(BigDecimal v, int dec) {
        return v.setScale(dec, RoundingMode.DOWN).toPlainString();
    }
    static String alpha(String s, int len) {
        return s.length() > len ? s.substring(0, len) : s;
    }
}

public class Eligible01 {
  public static void main(String[] args) {
    java.util.Scanner _sc = new java.util.Scanner(System.in);
    String WS_RAW = "";
    String WS_F1 = "";
    String WS_F2 = "";
    String WS_F3 = "";
    String WS_F4 = "";
    BigDecimal WS_INCOME = BigDecimal.ZERO;
    BigDecimal WS_SIZE = BigDecimal.ZERO;
    BigDecimal WS_AGE = BigDecimal.ZERO;
    String WS_DIS = "";
    BigDecimal WS_FPL = BigDecimal.ZERO;
    BigDecimal WS_PCT = BigDecimal.ZERO;
    String WS_STATUS = "";
    String WS_CAT = "";
    String WS_O_PCT = "";
    int BI = 1;
    WS_RAW = _sc.hasNextLine() ? _sc.nextLine() : "";
    String[] _p = WS_RAW.split(",", -1);
    WS_F1 = _p.length > 0 ? _p[0] : "";
    WS_F2 = _p.length > 1 ? _p[1] : "";
    WS_F3 = _p.length > 2 ? _p[2] : "";
    WS_F4 = _p.length > 3 ? _p[3] : "";
    WS_INCOME = R.st(new BigDecimal(R.numval(WS_F1)), 2, false);
    WS_SIZE = R.st(new BigDecimal(R.numval(WS_F2)), 0, false);
    WS_AGE = R.st(new BigDecimal(R.numval(WS_F3)), 0, false);
    WS_DIS = R.alpha(WS_F4.trim(), 1);
    WS_FPL = R.st(new BigDecimal("15060").add(WS_SIZE.subtract(new BigDecimal("1")).multiply(new BigDecimal("5380"))), 2, false);
    WS_PCT = R.st(WS_INCOME.divide(WS_FPL, 20, RoundingMode.DOWN).multiply(new BigDecimal("100")), 2, true);
    WS_STATUS = R.alpha("DENIED", 10);
    WS_CAT = R.alpha("NONE", 12);
    if ((WS_AGE).compareTo(new BigDecimal("19")) < 0 && (WS_PCT).compareTo(new BigDecimal("212.00")) <= 0) {
      WS_STATUS = R.alpha("APPROVED", 10);
      WS_CAT = R.alpha("CHILD", 12);
    } else if (R.eq(WS_DIS, "Y") && (WS_PCT).compareTo(new BigDecimal("200.00")) <= 0) {
      WS_STATUS = R.alpha("APPROVED", 10);
      WS_CAT = R.alpha("DISABILITY", 12);
    } else if ((WS_AGE).compareTo(new BigDecimal("65")) >= 0 && (WS_PCT).compareTo(new BigDecimal("150.00")) <= 0) {
      WS_STATUS = R.alpha("APPROVED", 10);
      WS_CAT = R.alpha("AGED", 12);
    } else if ((WS_PCT).compareTo(new BigDecimal("138.00")) <= 0) {
      WS_STATUS = R.alpha("APPROVED", 10);
      WS_CAT = R.alpha("EXPANSION", 12);
    } else if ((WS_PCT).compareTo(new BigDecimal("200.00")) <= 0) {
      WS_STATUS = R.alpha("PENDING", 10);
      WS_CAT = R.alpha("REVIEW", 12);
    }
    WS_O_PCT = R.dedit(WS_PCT, 2);
    System.out.println("STATUS=" + WS_STATUS.trim() + " CATEGORY=" + WS_CAT.trim() + " FPLPCT=" + WS_O_PCT.trim());
    return;
  }
}
