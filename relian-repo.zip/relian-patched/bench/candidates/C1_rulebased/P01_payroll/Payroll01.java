
import java.math.BigDecimal;
import java.math.RoundingMode;

final class R {
    static BigDecimal st(BigDecimal v, int scale, boolean rounded) {
        return v.setScale(scale, rounded ? RoundingMode.HALF_UP : RoundingMode.DOWN);
    }
    static String numval(String s) { s = s.trim(); return s.isEmpty() ? "0" : s; }
    static boolean eq(String a, String b) {
        return rtrim(a).equals(rtrim(b));
    }
    static String rtrim(String s) { int e = s.length(); while (e>0 && s.charAt(e-1)==' ') e--; return s.substring(0,e); }
    static int ix(BigDecimal v) { return v.intValue(); }
    static int ix(int v) { return v; }
    /* unedited numeric DISPLAY: zero-padded to declared digits */
    static String dnum(BigDecimal v, int intd, int dec) {
        BigDecimal x = v.setScale(dec, RoundingMode.DOWN);
        String s = x.abs().toPlainString();
        String ip = dec > 0 ? s.substring(0, s.indexOf('.')) : s;
        while (ip.length() < intd) ip = "0" + ip;
        String r = dec > 0 ? ip + s.substring(s.indexOf('.')) : ip;
        return (v.signum() < 0 ? "-" : "") + r;
    }
    /* edited picture then TRIM: plain decimal at edit scale */
    static String dedit(BigDecimal v, int dec) {
        return v.setScale(dec, RoundingMode.DOWN).toPlainString();
    }
    static String alpha(String s, int len) {
        return s.length() > len ? s.substring(0, len) : s;
    }
}

public class Payroll01 {
  public static void main(String[] args) {
    java.util.Scanner _sc = new java.util.Scanner(System.in);
    String WS_RAW = "";
    BigDecimal WS_HOURS = BigDecimal.ZERO;
    BigDecimal WS_RATE = BigDecimal.ZERO;
    BigDecimal WS_DEPS = BigDecimal.ZERO;
    BigDecimal WS_REG_HOURS = BigDecimal.ZERO;
    BigDecimal WS_OT_HOURS = BigDecimal.ZERO;
    BigDecimal WS_GROSS = BigDecimal.ZERO;
    BigDecimal WS_TAXABLE = BigDecimal.ZERO;
    BigDecimal WS_TAX = BigDecimal.ZERO;
    BigDecimal WS_NET = BigDecimal.ZERO;
    BigDecimal WS_DED = BigDecimal.ZERO;
    String WS_F1 = "";
    String WS_F2 = "";
    String WS_F3 = "";
    String WS_O_GROSS = "";
    String WS_O_NET = "";
    String WS_O_TAX = "";
    int BI = 1;
    WS_RAW = _sc.hasNextLine() ? _sc.nextLine() : "";
    String[] _p = WS_RAW.split(",", -1);
    WS_F1 = _p.length > 0 ? _p[0] : "";
    WS_F2 = _p.length > 1 ? _p[1] : "";
    WS_F3 = _p.length > 2 ? _p[2] : "";
    WS_HOURS = R.st(new BigDecimal(R.numval(WS_F1)), 2, false);
    WS_RATE = R.st(new BigDecimal(R.numval(WS_F2)), 2, false);
    WS_DEPS = R.st(new BigDecimal(R.numval(WS_F3)), 0, false);
    if ((WS_HOURS).compareTo(new BigDecimal("40.00")) > 0) {
      WS_REG_HOURS = R.st(new BigDecimal("40.00"), 2, false);
      WS_OT_HOURS = R.st(WS_HOURS.subtract(new BigDecimal("40.00")), 2, false);
    } else {
      WS_REG_HOURS = R.st(WS_HOURS, 2, false);
      WS_OT_HOURS = R.st(BigDecimal.ZERO, 2, false);
    }
    WS_GROSS = R.st(WS_REG_HOURS.multiply(WS_RATE).add(WS_OT_HOURS.multiply(WS_RATE).multiply(new BigDecimal("1.5"))), 2, true);
    WS_DED = R.st(WS_DEPS.multiply(new BigDecimal("76.92")), 2, false);
    WS_TAXABLE = R.st(WS_GROSS.subtract(WS_DED), 2, false);
    if ((WS_TAXABLE).compareTo(new BigDecimal("0")) < 0) {
      WS_TAXABLE = R.st(BigDecimal.ZERO, 2, false);
    }
    if ((WS_TAXABLE).compareTo(new BigDecimal("500.00")) <= 0) {
      WS_TAX = R.st(WS_TAXABLE.multiply(new BigDecimal("0.10")), 2, true);
    } else if ((WS_TAXABLE).compareTo(new BigDecimal("1500.00")) <= 0) {
      WS_TAX = R.st(new BigDecimal("50.00").add(WS_TAXABLE.subtract(new BigDecimal("500.00")).multiply(new BigDecimal("0.22"))), 2, true);
    } else {
      WS_TAX = R.st(new BigDecimal("270.00").add(WS_TAXABLE.subtract(new BigDecimal("1500.00")).multiply(new BigDecimal("0.32"))), 2, true);
    }
    WS_NET = R.st(WS_GROSS.subtract(WS_TAX), 2, false);
    WS_O_GROSS = R.dedit(WS_GROSS, 2);
    WS_O_NET = R.dedit(WS_NET, 2);
    WS_O_TAX = R.dedit(WS_TAX, 2);
    System.out.println("GROSS=" + WS_O_GROSS.trim() + " NET=" + WS_O_NET.trim() + " TAX=" + WS_O_TAX.trim());
    return;
  }
}
