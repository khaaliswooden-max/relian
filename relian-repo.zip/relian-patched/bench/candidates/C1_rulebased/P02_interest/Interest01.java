
import java.math.BigDecimal;
import java.math.RoundingMode;

final class R {
    static BigDecimal st(BigDecimal v, int scale, boolean rounded) {
        return v.setScale(scale, rounded ? RoundingMode.HALF_UP : RoundingMode.DOWN);
    }
    static String numval(String s) { s = s.trim(); return s.isEmpty() ? "0" : s; }
    static boolean eq(String a, String b) {
        return rtrim(a).equals(rtrim(b));
    }
    static String rtrim(String s) { int e = s.length(); while (e>0 && s.charAt(e-1)==' ') e--; return s.substring(0,e); }
    static int ix(BigDecimal v) { return v.intValue(); }
    static int ix(int v) { return v; }
    /* unedited numeric DISPLAY: zero-padded to declared digits */
    static String dnum(BigDecimal v, int intd, int dec) {
        BigDecimal x = v.setScale(dec, RoundingMode.DOWN);
        String s = x.abs().toPlainString();
        String ip = dec > 0 ? s.substring(0, s.indexOf('.')) : s;
        while (ip.length() < intd) ip = "0" + ip;
        String r = dec > 0 ? ip + s.substring(s.indexOf('.')) : ip;
        return (v.signum() < 0 ? "-" : "") + r;
    }
    /* edited picture then TRIM: plain decimal at edit scale */
    static String dedit(BigDecimal v, int dec) {
        return v.setScale(dec, RoundingMode.DOWN).toPlainString();
    }
    static String alpha(String s, int len) {
        return s.length() > len ? s.substring(0, len) : s;
    }
}

public class Interest01 {
  public static void main(String[] args) {
    java.util.Scanner _sc = new java.util.Scanner(System.in);
    String WS_RAW = "";
    String WS_F1 = "";
    String WS_F2 = "";
    String WS_F3 = "";
    String WS_F4 = "";
    BigDecimal WS_PRIN = BigDecimal.ZERO;
    BigDecimal WS_RATE = BigDecimal.ZERO;
    BigDecimal WS_YEARS = BigDecimal.ZERO;
    BigDecimal WS_ADD = BigDecimal.ZERO;
    BigDecimal WS_BAL = BigDecimal.ZERO;
    BigDecimal WS_MRATE = BigDecimal.ZERO;
    BigDecimal WS_INT = BigDecimal.ZERO;
    BigDecimal WS_TOTADD = BigDecimal.ZERO;
    BigDecimal I = BigDecimal.ZERO;
    BigDecimal WS_MONTHS = BigDecimal.ZERO;
    String WS_O_BAL = "";
    String WS_O_INT = "";
    int BI = 1;
    WS_RAW = _sc.hasNextLine() ? _sc.nextLine() : "";
    String[] _p = WS_RAW.split(",", -1);
    WS_F1 = _p.length > 0 ? _p[0] : "";
    WS_F2 = _p.length > 1 ? _p[1] : "";
    WS_F3 = _p.length > 2 ? _p[2] : "";
    WS_F4 = _p.length > 3 ? _p[3] : "";
    WS_PRIN = R.st(new BigDecimal(R.numval(WS_F1)), 2, false);
    WS_RATE = R.st(new BigDecimal(R.numval(WS_F2)), 4, false);
    WS_YEARS = R.st(new BigDecimal(R.numval(WS_F3)), 0, false);
    WS_ADD = R.st(new BigDecimal(R.numval(WS_F4)), 2, false);
    WS_MRATE = R.st(WS_RATE.divide(new BigDecimal("100"), 20, RoundingMode.DOWN).divide(new BigDecimal("12"), 20, RoundingMode.DOWN), 8, false);
    WS_MONTHS = R.st(WS_YEARS.multiply(new BigDecimal("12")), 0, false);
    WS_BAL = R.st(WS_PRIN, 2, false);
    WS_TOTADD = R.st(BigDecimal.ZERO, 2, false);
    for (I = new BigDecimal("1"); !((I).compareTo(WS_MONTHS) > 0); I = I.add(new BigDecimal("1"))) {
      WS_BAL = R.st(WS_BAL.multiply(new BigDecimal("1").add(WS_MRATE)), 2, true);
      WS_BAL = R.st(WS_BAL.add(WS_ADD), 2, false);
      WS_TOTADD = R.st(WS_TOTADD.add(WS_ADD), 2, false);
    }
    WS_INT = R.st(WS_BAL.subtract(WS_PRIN).subtract(WS_TOTADD), 2, false);
    WS_O_BAL = R.dedit(WS_BAL, 2);
    WS_O_INT = R.dedit(WS_INT, 2);
    System.out.println("BAL=" + WS_O_BAL.trim() + " INT=" + WS_O_INT.trim());
    return;
  }
}
